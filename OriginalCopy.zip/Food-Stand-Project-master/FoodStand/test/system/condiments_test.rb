require "application_system_test_case"

class CondimentsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit condiments_url
  #
  #   assert_selector "h1", text: "Condiment"
  # end
end
