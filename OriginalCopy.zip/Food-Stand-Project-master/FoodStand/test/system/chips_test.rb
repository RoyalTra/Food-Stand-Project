require "application_system_test_case"

class ChipsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit chips_url
  #
  #   assert_selector "h1", text: "Chip"
  # end
end
