require "application_system_test_case"

class FoodsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit foods_url
  #
  #   assert_selector "h1", text: "Food"
  # end
end
