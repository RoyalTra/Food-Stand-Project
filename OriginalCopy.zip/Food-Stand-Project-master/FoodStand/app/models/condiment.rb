class Condiment < ApplicationRecord
end
