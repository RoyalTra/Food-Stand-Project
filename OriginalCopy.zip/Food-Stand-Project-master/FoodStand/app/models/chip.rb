class Chip < ApplicationRecord
end
