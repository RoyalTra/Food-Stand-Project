class Beverage < ApplicationRecord
end
