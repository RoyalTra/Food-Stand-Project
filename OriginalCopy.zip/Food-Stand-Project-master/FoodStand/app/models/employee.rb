class Employee < ApplicationRecord
end
